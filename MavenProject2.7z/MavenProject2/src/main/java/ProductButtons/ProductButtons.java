package ProductButtons;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class ProductButtons  {
	private WebElement buttonContainer;
	private By addcart=By.linkText("Add to cart" );
	private By morebutton=By.linkText("More");
	private By buttons=By.className("button-container");
	
	public ProductButtons (WebElement buttonContainer) {
		this.buttonContainer=buttonContainer;
	}
	public boolean isbuttonCointanerdisplayed() {
		return buttonContainer.isDisplayed();
	}
	public String containMoreOption() {
		
		return buttonContainer.findElement(buttons).findElement(morebutton).getText();
	}
public String containAddOption() {
		
		return buttonContainer.findElement(buttons).findElement(addcart).getText();
	}
}
