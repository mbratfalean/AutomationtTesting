package pages;

import java.util.List;
import java.util.stream.Collectors;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;

import ProductButtons.ProductButtons;


public class ProductInfoPage {
	private WebDriver driver;
	private By webElement=By.xpath("//*[@id=\"center_column\"]/ul");
	private By elementClass=By.className("product-image-container");
	private By container=By.className("right-block");
	
	public ProductInfoPage(WebDriver driver) {
		this.driver= driver;
		PageFactory.initElements(driver, this);
	}
	

}
