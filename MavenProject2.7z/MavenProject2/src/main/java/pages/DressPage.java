package pages;

import java.util.List;
import java.util.stream.Collectors;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class DressPage {

	private WebDriver driver;
	
	private By dressType=By.className("clearfix");
	private By dressTypeNmae=By.className("subcategory-name");
	
	public DressPage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	public List<String> alldresses(){
		return driver.findElement(dressType).findElements(dressTypeNmae).stream().map(e->e.getText()).collect(Collectors.toList());
	}
}
