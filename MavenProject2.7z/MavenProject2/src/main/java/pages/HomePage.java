package pages;

import java.util.List;
import org.openqa.selenium.JavascriptExecutor;	
import java.util.stream.Collectors;

import org.checkerframework.checker.units.qual.Length;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;


import ProductButtons.ProductButtons;


public class HomePage {
	private WebDriver driver;
	private  By formAuthenticationLink=By.xpath("/html/body/div/div[1]/header/div[2]/div/div/nav/div[1]/a");
	private  By searchIcon=By.name("submit_search");
	private By searchText=By.id("search_query_top");
	private By logoAPP=By.id("header_logo");
	private By productName=By.className("product-name");
	private By productlist=By.xpath("//*[@id=\"center_column\"]/ul/li");
	private By clotsCategory=By.xpath("//*[@id=\"block_top_menu\"]/ul/li[2]/a");
	private By container=By.className("button-container");
	private By webElement=By.xpath("//*[@id=\"homefeatured\"]");
	private WebElement buttonContainer;
	
	
	//private  By popUP=By.id("onesignal-slidedown-cancel-button");
	public HomePage(WebDriver driver) {
		this.driver= driver;
		PageFactory.initElements(driver, this);
	}
	

	public  LoginPage clickformAuthentication()  {
		
		
		driver.getTitle();
		//driver.findElement(popUP).click();
		
		driver.findElement(formAuthenticationLink).click();
		//Thread.sleep(3000);
		return new LoginPage(driver);
	
	
}
	public SearchPage clicksearchIcon(String inputSearch) {
		driver.findElement(searchText).sendKeys(inputSearch);
		driver.findElement(searchIcon).click();;
		return new SearchPage(driver);
	}

	 public HomePage clickLogo() {
		   driver.findElement(logoAPP).click();;
		   return new HomePage(driver);
	   }
	public HomePage home() {
		return new HomePage(driver);
	}
	public DressPage clickdress() {
		driver.findElement(clotsCategory).click();
		return new DressPage(driver);
	}
	 public WebElement hoverOver(String selectedProduct) {
		 Actions action=new Actions(driver);
		// WebElement buttonContainer ;
		
		 searchAllProduct();
		
		System.out.println(searchAllProduct().size());
		// System.out.println(driver.findElement(webElement).getTagName());
		 
		/*List<WebElement> productsList=productList.findElements(By.tagName("li"));*/
		 
		for(int i=0;i<searchAllProduct().size();i++) {
			
			if (searchAllProduct().get(i).equals(selectedProduct)) {
				System.out.println(searchAllProduct().get(i));
				buttonContainer=driver.findElement(By.linkText(searchAllProduct().get(i)));
				action.moveToElement(buttonContainer).perform();
			}
		
			
		
	}
		//System.out.println(buttonContainer.getClass());
		
		WebElement parent1 = (WebElement)( (JavascriptExecutor)driver)
				.executeScript("return arguments[0].parentNode;", buttonContainer);
		WebElement parentButtons = (WebElement)( (JavascriptExecutor)driver)
				.executeScript("return arguments[0].parentNode;", parent1);
	
		//System.out.println(parentButtons.getTagName());
		return parentButtons;	
	
		
		// System.out.println(driver.findElements(productlist).get(index-1).getTagName());
		//return new ProductButtons(buttonContainer);

}
	 public List<String> searchAllProduct(){
			
		 return	driver.findElement(webElement).findElements(productName).stream().map(e->e.getText()).collect(Collectors.toList());
			}

}