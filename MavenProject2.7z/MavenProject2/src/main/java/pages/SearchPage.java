package pages;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;



public class SearchPage {
	private WebDriver driver;
	private By searchResult=By.className("heading-counter");
	 private By webElement=By.xpath("//*[@id=\"center_column\"]/ul");
	 private By elementName=By.className("product-name");
	 	
	public SearchPage(WebDriver driver) {
		this.driver= driver;
		PageFactory.initElements(driver, this);
	}
	
	public String searchResult() {
		return driver.findElement(searchResult).getText();
	}
     public List<String > searchAllProduct(){
	
	return	driver.findElement(webElement).findElements(elementName).stream().map(e->e.getText()).collect(Collectors.toList());
	}
    public boolean webelementPrezent(){
    	Boolean isPresent = driver.findElements(webElement).size() > 0;
    	return isPresent;
    }

}
