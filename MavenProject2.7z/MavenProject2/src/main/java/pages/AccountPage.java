package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class AccountPage {
private WebDriver driver;
private By signOut=By.className("logout");
private By statusAlert=By.className("info-account");
public AccountPage(WebDriver driver) {
	this.driver=driver;
}
public String getAlertText() {
	return driver.findElement(statusAlert).getText();
}
public void signOut() {
	driver.findElement(signOut).click();
	
}
}
