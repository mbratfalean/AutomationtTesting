package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPage {
	private WebDriver driver;
	private By usernameField=By.id("email");
	private By Alert =By.xpath("/html/body/div/div[2]/div/div[3]/div/div[1]");
	private By passwordField=By.id("passwd" );
	private By loginButton =By.id("SubmitLogin");
	
	public LoginPage(WebDriver driver) {
		this.driver=driver;
	}
	public void setUsername(String username) {
		driver.findElement(usernameField).sendKeys(username);
	}  	
	public void setPassword(String password) {
		driver.findElement(passwordField).sendKeys(password);
	}
    
    public AccountPage clickLoginButton() {
    	driver.findElement(loginButton).click();
    	return new AccountPage(driver);
    }

   public String Alert() {
	return (driver.findElement(Alert).getText());
}
    

}
