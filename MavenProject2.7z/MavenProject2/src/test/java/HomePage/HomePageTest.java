package HomePage;


import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.Test;

import ProductButtons.ProductButtons;
import pages.HomePage;
import test.automation.BasicSetUp;

public class HomePageTest extends BasicSetUp {
	
	@Test
	public void hovertest() {
		homePage.home();
		homePage.hoverOver("Blouse");
		ProductButtons testButton =new ProductButtons(homePage.hoverOver("Blouse"));
		System.out.println(testButton.isbuttonCointanerdisplayed());
		assertEquals(testButton.isbuttonCointanerdisplayed(), true);
		//System.out.println(testButton.containMoreOption());
		assertTrue(testButton.containMoreOption().contains("More"));
		assertTrue(testButton.containAddOption().contains("Add"));
	}

}
