package test.automation;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import Login.LoginTest;

import org.junit.Test;
import org.junit.jupiter.api.BeforeAll;

import pages.HomePage;

public class BasicSetUp {
private WebDriver driver;
protected HomePage homePage;

	
    @Before
 	public void setUp(){
		System.setProperty("webdriver.chrome.driver","resources//chromedriver.exe");
		WebDriver driver = new  ChromeDriver();
		 driver.get("http://automationpractice.com/index.php");
		 driver.manage().window().maximize();
		 homePage = new HomePage(driver);
		 
	}
 	
 /*   @After
public void tearDown() {
    	WebDriver driver = new  ChromeDriver();
    	driver.quit();
    }*/


}
