package ProductInfoTest;
import org.junit.Test;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.platform.commons.annotation.Testable;

import ProductButtons.ProductButtons;
import pages.ProductInfoPage;
import test.automation.BasicSetUp;
import pages.HomePage;

public class ProductInfoTest extends BasicSetUp {
	
	@Test
	public void PageInfo() {
		homePage.home();
	  
	}

}

