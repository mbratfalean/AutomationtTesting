package Login;

import static org.junit.Assert.assertNotEquals;
import static org.junit.jupiter.api.Assertions.*;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.Scanner;

import org.junit.Test;
import org.openqa.selenium.By;

import pages.AccountPage;
import pages.HomePage;
import pages.LoginPage;
import test.automation.BasicSetUp;

public class LoginTest extends BasicSetUp {
 
 //@Test
public void testSuccesfullLogin() throws Exception {
	String[] password = wrigthPassword();
	String[] username = wrigthUsername();
	PrintWriter myWriter = new PrintWriter("resources//testingWrightcredential.txt");
	
	for(int i=0;i<username.length;i++) {
		for (int j=0;j<=password.length;j++) {
			LoginPage loginPage =homePage.clickformAuthentication();
			if(i==j) {
				myWriter.println(username[i]+" "+password[j]);
				loginPage.setUsername(username[i]);	
				loginPage.setPassword(password[j]);
				AccountPage accountPage=loginPage.clickLoginButton();
				assertEquals(accountPage.getAlertText(), "Welcome to your account. Here you can manage all of your personal information and orders.","Alert text");
				accountPage.signOut();
			}
		}
		
	}
	 myWriter.close();
	//LoginPage loginPage =homePage.clickformAuthentication();
		
 /*  loginPage.setUsername("JohnDoeTestingAutomation@gmail.com");
	loginPage.setPassword("JohnDoe123!");
	AccountPage accountPage=loginPage.clickLoginButton();
	assertEquals(accountPage.getAlertText(), "Welcome to your account. Here you can manage all of your personal information and orders.","Alert text");*/
}
//	@Test
	public void testUnsuccesfullLogin() throws Exception {
		String[] password = wrongPassword();
		String[] username = wrongUsername();
		PrintWriter myWriter = new PrintWriter("resources//testingWrongUserPassworg.txt");
		
		
		for(int i=0;i<username.length;i++) {
				for(int j=0;j<password.length;j++) {
				LoginPage loginPage =homePage.clickformAuthentication();
				loginPage.setUsername(username[i]);	
				loginPage.setPassword(password[j]);
				AccountPage accountPage=loginPage.clickLoginButton();
				
			assertTrue(loginPage.Alert().contains("There is 1 error"),"Alert no success");
	
			myWriter.println(username[i]+" "+password[j]);
				}
				
			}
				
		 myWriter.close();
			
		}
	/*	LoginPage loginPage =homePage.clickformAuthentication();
		loginPage.setUsername("an@gmail.com");
		loginPage.setPassword("JohnDoe123!");
		AccountPage accountPage=loginPage.clickLoginButton();
		assertEquals(loginPage.Alert(), "There is 1 error\r\n"+ "Authentication failed.","Alert text");*/


	static String[] wrongUsername() throws Exception {
		 Scanner s;
		  String data[]=new String[9];
		   s = new Scanner(new BufferedReader(new FileReader("resources//username.txt")));
		   for(int i = 0; i < data.length&&s.hasNextLine();i++)
		   {
		   data[i]= s.nextLine() ;
	}
		   return(data);
	}
	static String[] wrongPassword() throws Exception  {
		 Scanner t;
		  String data[]=new String[9];
		   t = new Scanner(new BufferedReader(new FileReader("resources//password.txt")));
		   for(int i = 0; i < data.length&&t.hasNextLine();i++)
		   {
		   data[i]= t.nextLine() ;
	}
		   return(data);
	}
	static String[] wrigthPassword() throws Exception  {
		 Scanner t;
		  String data[]=new String[2];
		   t = new Scanner(new BufferedReader(new FileReader("resources//successpassword.txt")));
		   for(int i = 0; i < data.length&&t.hasNextLine();i++)
		   {
		   data[i]= t.nextLine() ;
	}
		   return(data);
	}
	static String[] wrigthUsername() throws Exception  {
		 Scanner t;
		  String data[]=new String[2];
		   t = new Scanner(new BufferedReader(new FileReader("resources//successusername.txt")));
		   for(int i = 0; i < data.length&&t.hasNextLine();i++)
		   {
		   data[i]= t.nextLine() ;
	}
		   return(data);
	}

}



