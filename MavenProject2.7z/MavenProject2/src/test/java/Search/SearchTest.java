package Search;

import static org.junit.Assert.*;

import java.awt.List;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.PrintWriter;
import java.util.Scanner;

import org.junit.Test;
import org.openqa.selenium.By;

import pages.DressPage;
import pages.LoginPage;
import pages.SearchPage;
import test.automation.BasicSetUp;

public class SearchTest extends BasicSetUp {
	
	@Test
	
	public void testSuccesfullSearch() throws Exception{
		
		String[] searchsuccess=searchsuccess();
	
		for(int i=0;i<searchsuccess.length;i++) {
			SearchPage searchpage=homePage.clicksearchIcon(searchsuccess[i]);
			searchpage.searchResult();
			assertTrue(searchpage.searchResult().contains(" been found."));
			homePage.clickLogo();
		}
		
			
		//DressPage dresspage=homePage.clickdress();
	
		
	}
	//@Test
	public void testreturnedSearchelement() {
		String searchItem="Dress";
		SearchPage searchpage=homePage.clicksearchIcon(searchItem);
		 assertNotEquals(searchpage.searchAllProduct().size(),0);
		for(int i=0;i<searchpage.searchAllProduct().size();i++){
			assertTrue(searchpage.searchAllProduct().get(i).contains(searchItem));
		    System.out.println(searchpage.searchAllProduct().get(i));
		    
		} 
		//System.out.println(searchpage.searchAllProduct());
	}
	//@Test
	public void testUnsseccesfullSearch() throws Exception {
		
		String[] searchunsuccssesfull=searchunsuccessfull();
		
		for (int i=0;i<searchunsuccssesfull.length;i++) {
			SearchPage searchpage=homePage.clicksearchIcon(searchunsuccssesfull[i]);
			assertEquals(searchpage.webelementPrezent(),false);
			homePage.clickLogo();
		}
	}
	
	static String[] searchsuccess() throws Exception {
		 Scanner s;
		  String data[]=new String[2];
		   s = new Scanner(new BufferedReader(new FileReader("resources//successfullsearch.txt")));
		   for(int i = 0; i < data.length&&s.hasNextLine();i++)
		   {
		   data[i]= s.nextLine() ;
	}
		   return(data);
	
}
	static String[] searchunsuccessfull() throws Exception {
		 Scanner s;
		  String data[]=new String[9];
		   s = new Scanner(new BufferedReader(new FileReader("resources//password.txt")));
		   for(int i = 0; i < data.length&&s.hasNextLine();i++)
		   {
		   data[i]= s.nextLine() ;
	}
		   return(data);
	
}
	

}
