package DressPage;

import static org.junit.Assert.assertTrue;

import org.junit.jupiter.api.Test;

import pages.DressPage;
import test.automation.BasicSetUp;
import pages.HomePage;

public class DressPageTest extends BasicSetUp {
	@Test
	public void testDress1() throws Exception {
		DressPage dresspage=homePage.clickdress();
		dresspage.wait();
		//dresspage.alldresses();
		
	}

}
